/// <mls fileReference="_102031_/l2/pt/terms.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
