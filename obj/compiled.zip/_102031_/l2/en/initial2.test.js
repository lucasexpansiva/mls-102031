/// <mls fileReference="_102031_/l2/en/initial2.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
