/// <mls fileReference="_102031_/l2/en/landingpage.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
