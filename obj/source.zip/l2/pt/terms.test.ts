/// <mls fileReference="_102031_/l2/pt/terms.test.ts" enhancement="_blank"/>

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];